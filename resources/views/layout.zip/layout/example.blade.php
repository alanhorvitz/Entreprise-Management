@extends('layout.app')

@section('title', 'Dashboard Home')

@section('content')
    <h2 class="text-2xl font-bold mb-4">Welcome to your dashboard</h2>
    <p>This is your main content area.</p>
@endsection